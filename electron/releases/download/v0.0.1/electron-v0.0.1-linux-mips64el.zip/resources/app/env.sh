export ELECTRON_MIRROR=http://ftp.loongnix.org/
export ELECTRON_CUSTOM_DIR="os/loongnix/1.0/electron/electron/mirror/electron-v6.1.7"
export ELECTRON_CUSTOM_FILENAME="electron-v6.1.7-linux-mips64el.zip"
